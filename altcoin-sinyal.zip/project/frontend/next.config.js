/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // API isteklerini backend'e yönlendir (same-origin proxy — opsiyonel)
  // NEXT_PUBLIC_API_BASE_URL set edilmişse bu rewrites kullanılmaz
  async rewrites() {
    const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL;
    if (!apiBase) return [];
    return [];
  },
};

module.exports = nextConfig;
