import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        bg: {
          base:  "#0B0F19",
          card:  "#111827",
          card2: "#0F1623",
          input: "#0d1117",
        },
        border: {
          DEFAULT: "#1f2937",
          strong:  "#374151",
        },
        signal: {
          al:    "#10b981",
          sat:   "#ef4444",
          bekle: "#f59e0b",
        },
      },
    },
  },
  plugins: [],
};

export default config;
