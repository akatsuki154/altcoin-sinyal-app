"use client";

// Ana uygulama bileşenini doğrudan buraya import ediyoruz.
// Tüm sayfa mantığı AltcoinApp içinde.
import AltcoinApp from "@/components/AltcoinApp";

export default function Home() {
  return <AltcoinApp />;
}
