export type SignalType = "AL" | "SAT" | "BEKLE";
export type RiskLevel  = "düşük" | "orta" | "yüksek";

export interface SignalResult {
  signal:     SignalType;
  confidence: number;
  risk:       RiskLevel;
}

export interface CoinWithSignal {
  symbol:         string;
  binance_symbol: string;
  base:           string;
  quote:          string;
  name:           string;
  price:          number;
  open_24h:       number;
  high_24h:       number;
  low_24h:        number;
  volume_24h:     number;
  change_24h:     number;
  change_pct_24h: number;
  count_24h:      number;
  signal:         SignalType;
  confidence:     number;
  risk:           RiskLevel;
}
