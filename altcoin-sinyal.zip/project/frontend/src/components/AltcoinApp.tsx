"use client";

/**
 * AltcoinSinyal — Üretim Kalitesi Kripto Analiz Uygulaması
 *
 * Düzeltmeler (v1.1):
 * 1. Gerçek Binance API entegrasyonu (ccxt yerine doğrudan REST — tarayıcıdan erişilebilir)
 * 2. Fiyat formatlama hatası düzeltildi — locale/yuvarlama/birim sorunları giderildi
 * 3. Tam dark mode — tüm elementler koyu tema ile uyumlu
 * 4. Veri tutarlılığı — tek kaynak, tutarlı format
 * 5. Otomatik yenileme — 10 saniyede bir fiyat güncelleme
 */

import { useState, useEffect, useCallback, useRef, memo } from "react";

// ─── SABİTLER ──────────────────────────────────────────────────────────────────

// Desteklenen coinler ve meta bilgileri
const COIN_META = {
  "BTCUSDT":  { name: "Bitcoin",   symbol: "BTC/USDT",  base: "BTC"   },
  "ETHUSDT":  { name: "Ethereum",  symbol: "ETH/USDT",  base: "ETH"   },
  "SOLUSDT":  { name: "Solana",    symbol: "SOL/USDT",  base: "SOL"   },
  "BNBUSDT":  { name: "BNB",       symbol: "BNB/USDT",  base: "BNB"   },
  "ADAUSDT":  { name: "Cardano",   symbol: "ADA/USDT",  base: "ADA"   },
  "AVAXUSDT": { name: "Avalanche", symbol: "AVAX/USDT", base: "AVAX"  },
  "DOTUSDT":  { name: "Polkadot",  symbol: "DOT/USDT",  base: "DOT"   },
  "LINKUSDT": { name: "Chainlink", symbol: "LINK/USDT", base: "LINK"  },
  "MATICUSDT":{ name: "Polygon",   symbol: "MATIC/USDT",base: "MATIC" },
  "ATOMUSDT": { name: "Cosmos",    symbol: "ATOM/USDT", base: "ATOM"  },
};

const COIN_SYMBOLS = Object.keys(COIN_META);

// Binance public API — CORS açık, API key gerekmez
const BINANCE_BASE = "https://api.binance.com/api/v3";

// Fiyat yenileme aralığı (ms)
const PRICE_REFRESH_MS = 10_000;

// ─── GERÇEK BİNANCE API FONKSİYONLARI ─────────────────────────────────────────
/**
 * Binance 24s ticker — tüm coinleri tek istekte çeker
 * Endpoint: GET /ticker/24hr?symbols=[...]
 * Backend ccxt karşılığı: fetch_ticker() / fetch_top_coins()
 */
async function fetchBinanceTickers(symbols) {
  const symbolsJson = JSON.stringify(symbols);
  const url = `${BINANCE_BASE}/ticker/24hr?symbols=${encodeURIComponent(symbolsJson)}`;

  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`Binance API hatası: ${res.status}`);
  const data = await res.json();

  const result = {};
  for (const t of data) {
    const meta = COIN_META[t.symbol];
    if (!meta) continue;
    result[t.symbol] = {
      // parseFloat: Binance string döner — kesin sayıya çevir
      price:          parseFloat(t.lastPrice),
      open_24h:       parseFloat(t.openPrice),
      high_24h:       parseFloat(t.highPrice),
      low_24h:        parseFloat(t.lowPrice),
      volume_24h:     parseFloat(t.quoteVolume), // USDT cinsinden hacim
      change_24h:     parseFloat(t.priceChange),
      change_pct_24h: parseFloat(t.priceChangePercent),
      count_24h:      parseInt(t.count, 10),
      symbol:         meta.symbol,
      name:           meta.name,
      base:           meta.base,
      binanceSymbol:  t.symbol,
    };
  }
  return result;
}

/**
 * Binance OHLCV (kline) — tek coin, belirli zaman dilimi
 * Backend ccxt karşılığı: fetch_ohlcv()
 */
async function fetchBinanceKlines(binanceSymbol, interval = "1h", limit = 60) {
  const url = `${BINANCE_BASE}/klines?symbol=${binanceSymbol}&interval=${interval}&limit=${limit}`;
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`Kline hatası: ${res.status}`);
  const raw = await res.json();
  return raw.map(k => ({
    time:   k[0],
    open:   parseFloat(k[1]),
    high:   parseFloat(k[2]),
    low:    parseFloat(k[3]),
    close:  parseFloat(k[4]),
    volume: parseFloat(k[5]),
  }));
}

// ─── FİYAT FORMATLAMA ──────────────────────────────────────────────────────────
/**
 * DÜZELTİLEN HATALAR:
 * - toLocaleString("tr-TR") → Türkçe locale nokta/virgül ters
 * - toFixed(3) her zaman → küçük sayılarda anlamsız yuvarlama
 * - 1e9 için "M" yazıyordu (yanlış, milyar "B" olmalı)
 */
function fmtPrice(price) {
  if (price === null || price === undefined || isNaN(price)) return "—";
  const p = Number(price);
  if (p >= 10000) return p.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (p >= 1000)  return p.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (p >= 100)   return p.toFixed(2);
  if (p >= 10)    return p.toFixed(3);
  if (p >= 1)     return p.toFixed(4);
  if (p >= 0.01)  return p.toFixed(5);
  if (p >= 0.001) return p.toFixed(6);
  return p.toFixed(8);
}

// DÜZELTİLDİ: T=trilyon, B=milyar, M=milyon, K=bin
function fmtVolume(v) {
  if (!v || isNaN(v)) return "—";
  const n = Number(v);
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9)  return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6)  return `$${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3)  return `$${(n / 1e3).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}

function fmtPct(pct) {
  if (pct === null || pct === undefined || isNaN(pct)) return "—";
  const sign = Number(pct) >= 0 ? "+" : "";
  return `${sign}${Number(pct).toFixed(2)}%`;
}

// ─── HIZLI SİNYAL (frontend tahmini, gerçek sinyal backend'den gelir) ──────────
function quickSignal(coin) {
  const c = coin.change_pct_24h;
  const v = coin.volume_24h;
  const highVol = v > 500_000_000;
  if (c > 3 && highVol)  return { signal: "AL",    confidence: 72, risk: "orta" };
  if (c > 1.5)           return { signal: "AL",    confidence: 57, risk: "orta" };
  if (c < -4 && highVol) return { signal: "SAT",   confidence: 68, risk: "yüksek" };
  if (c < -2)            return { signal: "SAT",   confidence: 54, risk: "yüksek" };
  return                        { signal: "BEKLE", confidence: 40, risk: "orta" };
}

// ─── RENK YARDIMCILARI ─────────────────────────────────────────────────────────
const SIG_COLORS = {
  AL:    { main: "#10b981", bg: "rgba(16,185,129,0.10)", border: "rgba(16,185,129,0.25)", text: "#10b981" },
  SAT:   { main: "#ef4444", bg: "rgba(239,68,68,0.10)",  border: "rgba(239,68,68,0.25)",  text: "#ef4444" },
  BEKLE: { main: "#f59e0b", bg: "rgba(245,158,11,0.10)", border: "rgba(245,158,11,0.25)", text: "#f59e0b" },
};
const sc = s => SIG_COLORS[s] || SIG_COLORS.BEKLE;

function getRiskColor(r) {
  return r === "düşük" ? "#10b981" : r === "yüksek" ? "#ef4444" : "#f59e0b";
}

// ─── GLOBAL DARK TEMA CSS ──────────────────────────────────────────────────────
const GCSS = `
*, *::before, *::after { box-sizing: border-box; }
:root { color-scheme: dark; }
body, html { background: #0B0F19 !important; color: #f3f4f6 !important; margin:0; padding:0; -webkit-font-smoothing: antialiased; }
select { background-color: #1f2937 !important; color: #f3f4f6 !important; border-color: #374151 !important; -webkit-appearance: none; appearance: none; }
select option { background-color: #111827 !important; color: #f3f4f6 !important; }
input, textarea { background-color: #0d1117 !important; color: #f3f4f6 !important; border-color: #1f2937 !important; }
input::placeholder, textarea::placeholder { color: #4b5563 !important; }
input:focus, select:focus { outline: none !important; border-color: #3b82f6 !important; box-shadow: 0 0 0 1px rgba(59,130,246,0.25) !important; }
::-webkit-scrollbar { width:4px; height:4px; } ::-webkit-scrollbar-track { background:#0B0F19; } ::-webkit-scrollbar-thumb { background:#374151; border-radius:2px; }
@keyframes pulse-d { 0%,100%{opacity:1} 50%{opacity:.35} }
.pd { animation: pulse-d 2s ease-in-out infinite; }
@keyframes fi { from{opacity:0;transform:translateY(5px)} to{opacity:1;transform:translateY(0)} }
.fi { animation: fi .22s ease-out forwards; }
@keyframes shimmer { 0%{background-position:-400px 0} 100%{background-position:400px 0} }
.sk { background:linear-gradient(90deg,#1f2937 25%,#2d3748 50%,#1f2937 75%); background-size:400px 100%; animation:shimmer 1.5s infinite; border-radius:6px; }
`;

// ─── YÜKLEME İSKELETİ ─────────────────────────────────────────────────────────
function Skeleton() {
  return (
    <div style={{ background:"#111827", border:"1px solid #1f2937", borderRadius:"16px", padding:"16px" }}>
      <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"12px" }}>
        <div className="sk" style={{ width:40, height:40, borderRadius:12 }} />
        <div style={{ flex:1 }}>
          <div className="sk" style={{ height:14, width:80, marginBottom:6 }} />
          <div className="sk" style={{ height:11, width:60 }} />
        </div>
      </div>
      <div className="sk" style={{ height:20, width:120, marginBottom:8 }} />
      <div className="sk" style={{ height:6, width:"100%" }} />
    </div>
  );
}

// ─── SİNYAL ROZET ─────────────────────────────────────────────────────────────
function SBadge({ signal, lg }) {
  const c = sc(signal);
  return (
    <span style={{
      display:"inline-flex", alignItems:"center", gap:6,
      padding: lg ? "6px 16px" : "2px 10px",
      borderRadius: 999,
      background: c.bg, border:`1px solid ${c.border}`, color: c.text,
      fontSize: lg ? 13 : 11, fontWeight: 700, letterSpacing: lg ? 2 : 1,
    }}>
      <span className="pd" style={{ width:6, height:6, borderRadius:"50%", background:c.main, display:"inline-block" }} />
      {signal}
    </span>
  );
}

// ─── COIN KARTI ────────────────────────────────────────────────────────────────
const CoinCard = memo(function CoinCard({ coin, onClick, isFav, onFav }) {
  const { signal, confidence } = quickSignal(coin);
  const c = sc(signal);
  const chg = coin.change_pct_24h;

  return (
    <div className="fi"
      onClick={() => onClick({ ...coin, signal, confidence })}
      style={{ background:"#111827", border:"1px solid #1f2937", borderRadius:16, padding:16, cursor:"pointer", transition:"border-color .15s, background .15s" }}
      onMouseEnter={e=>{ e.currentTarget.style.borderColor="#374151"; e.currentTarget.style.background="#141f2e"; }}
      onMouseLeave={e=>{ e.currentTarget.style.borderColor="#1f2937"; e.currentTarget.style.background="#111827"; }}
    >
      {/* Üst: avatar + isim + favori */}
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:12 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{
            width:40, height:40, borderRadius:12, display:"flex", alignItems:"center", justifyContent:"center",
            fontWeight:700, fontSize:11, background:c.bg, border:`1px solid ${c.border}`, color:c.main,
          }}>
            {coin.base.slice(0,3)}
          </div>
          <div>
            <div style={{ fontWeight:600, fontSize:14, color:"#f3f4f6", lineHeight:1.2 }}>{coin.base}</div>
            <div style={{ fontSize:11, color:"#6b7280", marginTop:2 }}>{coin.name}</div>
          </div>
        </div>
        <button
          onClick={e=>{ e.stopPropagation(); onFav(coin.symbol); }}
          style={{ padding:6, borderRadius:8, background:"transparent", border:"none", cursor:"pointer", color: isFav?"#f59e0b":"#4b5563" }}
        >
          <svg width={16} height={16} viewBox="0 0 24 24" fill={isFav?"currentColor":"none"} stroke="currentColor" strokeWidth={1.8}>
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </button>
      </div>

      {/* Fiyat + sinyal */}
      <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", marginBottom:12 }}>
        <div>
          {/* DÜZELTME: fmtPrice — doğru ondalık, locale hatası yok */}
          <div style={{ fontWeight:700, fontSize:18, color:"#f3f4f6", lineHeight:1 }}>${fmtPrice(coin.price)}</div>
          <div style={{ fontSize:13, fontWeight:500, marginTop:4, color: chg>=0?"#10b981":"#ef4444" }}>{fmtPct(chg)}</div>
        </div>
        <SBadge signal={signal} />
      </div>

      {/* Güven */}
      <div style={{ marginBottom:8 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
          <span style={{ fontSize:11, color:"#6b7280" }}>Güven Skoru</span>
          <span style={{ fontSize:11, fontWeight:600, color:c.text }}>%{confidence}</span>
        </div>
        <div style={{ height:5, background:"#1f2937", borderRadius:3, overflow:"hidden" }}>
          <div style={{ height:"100%", width:`${confidence}%`, borderRadius:3, background: confidence>=65?"#10b981":confidence>=45?"#f59e0b":"#ef4444", transition:"width .4s" }} />
        </div>
      </div>

      {/* Hacim — DÜZELTME: fmtVolume birim hatası giderildi */}
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:8, borderTop:"1px solid #1f2937" }}>
        <span style={{ fontSize:11, color:"#4b5563" }}>24s Hacim</span>
        <span style={{ fontSize:11, fontWeight:500, color:"#6b7280" }}>{fmtVolume(coin.volume_24h)}</span>
      </div>
    </div>
  );
});

// ─── MUM GRAFİĞİ ──────────────────────────────────────────────────────────────
function CandleChart({ klines, signal }) {
  if (!klines?.length) return <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100%", color:"#4b5563", fontSize:12 }}>Yükleniyor...</div>;
  const data = klines.slice(-40);
  const vals = data.flatMap(c=>[c.high,c.low]);
  const min = Math.min(...vals), max = Math.max(...vals), range = max-min||1;
  const sy = v => 95-((v-min)/range)*85;
  const W = 100/data.length;
  const sigColor = signal==="AL"?"#10b981":signal==="SAT"?"#ef4444":"#f59e0b";
  const lp = data.map((c,i)=>`${i*W+W/2},${sy((c.open+c.close)/2)}`).join(" ");
  const ap = `0,95 ${lp} ${(data.length-1)*W+W/2},95`;
  const gid = `g${signal}`;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width:"100%", height:"100%" }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={sigColor} stopOpacity="0.18" />
          <stop offset="100%" stopColor={sigColor} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      <polygon points={ap} fill={`url(#${gid})`} />
      {data.map((c,i)=>{
        const x=i*W+W/2, bull=c.close>=c.open, col=bull?"#10b981":"#ef4444";
        const bt=sy(Math.max(c.open,c.close)), bb=sy(Math.min(c.open,c.close)), bh=Math.max(.4,bb-bt);
        return <g key={i}>
          <line x1={x} y1={sy(c.high)} x2={x} y2={sy(c.low)} stroke={col} strokeWidth=".25" strokeOpacity=".5" />
          <rect x={x-W*.28} y={bt} width={W*.56} height={bh} fill={col} fillOpacity=".85" rx=".15" />
        </g>;
      })}
      <polyline points={lp} fill="none" stroke={sigColor} strokeWidth=".4" strokeOpacity=".3" />
    </svg>
  );
}

// ─── ANA SAYFA ─────────────────────────────────────────────────────────────────
function AnaSayfa({ coins, loading, error, onRetry, onCoinSelect, favs, onFav, lastUpdated }) {
  const [search, setSearch] = useState("");
  const [filt, setFilt] = useState("tümü");
  const enriched = coins.map(c=>({...c,...quickSignal(c)}));
  const filtered = enriched.filter(c=>{
    const q=search.toLowerCase();
    const match=c.base.toLowerCase().includes(q)||c.name.toLowerCase().includes(q);
    if (!match) return false;
    if (filt==="al") return c.signal==="AL";
    if (filt==="sat") return c.signal==="SAT";
    if (filt==="bekle") return c.signal==="BEKLE";
    return true;
  });
  const topSig = enriched.filter(c=>c.signal==="AL").sort((a,b)=>b.confidence-a.confidence).slice(0,3);
  const risks  = enriched.filter(c=>c.signal==="SAT"||c.risk==="yüksek").slice(0,3);
  const pos    = enriched.filter(c=>c.change_pct_24h>0).length;
  const avgC   = enriched.length ? Math.round(enriched.reduce((s,c)=>s+c.confidence,0)/enriched.length) : 0;

  const Btn = ({active, children, onClick: oc}) => (
    <button onClick={oc} style={{
      padding:"6px 12px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer", transition:"all .15s",
      background: active?"#1d4ed8":"#111827", border:`1px solid ${active?"#2563eb":"#1f2937"}`, color: active?"#fff":"#6b7280",
    }}>{children}</button>
  );

  return (
    <div style={{ paddingBottom:96 }}>
      {/* Başlık */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", paddingTop:4, marginBottom:20 }}>
        <div>
          <h1 style={{ fontWeight:700, fontSize:20, color:"#f3f4f6", margin:0 }}>Piyasa</h1>
          <p style={{ fontSize:11, color:"#4b5563", margin:"2px 0 0" }}>
            {lastUpdated ? `Son güncelleme: ${lastUpdated}` : "Veri yükleniyor..."}
          </p>
        </div>
        {loading && (
          <div style={{ display:"flex", alignItems:"center", gap:6, padding:"4px 10px", borderRadius:8, background:"rgba(59,130,246,0.1)", border:"1px solid rgba(59,130,246,0.2)" }}>
            <div className="pd" style={{ width:6, height:6, borderRadius:"50%", background:"#60a5fa" }} />
            <span style={{ fontSize:11, fontWeight:600, color:"#60a5fa" }}>Güncelleniyor</span>
          </div>
        )}
      </div>

      {/* Piyasa özeti */}
      <div style={{ borderRadius:16, padding:16, marginBottom:20, background:"linear-gradient(135deg,#0d1f3c 0%,#111827 100%)", border:"1px solid #1f3a5f" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
          <span style={{ fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:2, color:"#60a5fa" }}>Piyasa Özeti</span>
          <span style={{ fontSize:11, color:"#374151" }}>{enriched.length} coin takipte</span>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
          {[{v:pos,l:"Yükselen",c:"#10b981"},{v:enriched.length-pos,l:"Düşen",c:"#ef4444"},{v:`%${avgC}`,l:"Ort. Güven",c:"#60a5fa"}].map((m,i)=>(
            <div key={i} style={{ textAlign:"center", borderLeft: i>0?"1px solid #1f2937":"none", paddingLeft: i>0?0:0 }}>
              <div style={{ fontWeight:700, fontSize:22, color:m.c, lineHeight:1 }}>{m.v}</div>
              <div style={{ fontSize:11, color:"#6b7280", marginTop:4 }}>{m.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Hata */}
      {error && (
        <div style={{ borderRadius:12, padding:16, marginBottom:16, background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.2)", textAlign:"center" }}>
          <p style={{ color:"#9ca3af", fontSize:13, marginBottom:12 }}>{error}</p>
          <button onClick={onRetry} style={{ padding:"8px 16px", borderRadius:10, background:"#1d4ed8", border:"1px solid #2563eb", color:"#fff", fontSize:13, fontWeight:600, cursor:"pointer" }}>
            Tekrar Dene
          </button>
        </div>
      )}

      {/* Güçlü sinyaller */}
      {topSig.length>0 && (
        <div style={{ marginBottom:20 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:12 }}>
            <span style={{ fontWeight:600, fontSize:14, color:"#f3f4f6" }}>🔥 Bugünün En Güçlü Sinyalleri</span>
            <span style={{ fontSize:11, color:"#374151" }}>{topSig.length} sinyal</span>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {topSig.map((coin,i)=>(
              <div key={coin.symbol}
                onClick={()=>onCoinSelect(coin)}
                style={{ display:"flex", alignItems:"center", gap:12, padding:12, borderRadius:12, cursor:"pointer", background:"rgba(16,185,129,0.06)", border:"1px solid rgba(16,185,129,0.15)", transition:"border-color .15s" }}
                onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(16,185,129,0.35)"}
                onMouseLeave={e=>e.currentTarget.style.borderColor="rgba(16,185,129,0.15)"}
              >
                <div style={{ width:28, height:28, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(16,185,129,0.15)", border:"1px solid rgba(16,185,129,0.25)", color:"#10b981", fontWeight:700, fontSize:12 }}>{i+1}</div>
                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <span style={{ fontWeight:600, fontSize:13, color:"#f3f4f6" }}>{coin.base}</span>
                    <SBadge signal={coin.signal} />
                  </div>
                  <div style={{ fontSize:11, color:"#6b7280", marginTop:2 }}>
                    Güven: <span style={{ color:"#10b981", fontWeight:600 }}>%{coin.confidence}</span>
                    <span style={{ margin:"0 6px", color:"#374151" }}>·</span>
                    Risk: <span style={{ fontWeight:600, color:getRiskColor(coin.risk) }}>{coin.risk}</span>
                  </div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontSize:13, fontWeight:600, color:"#f3f4f6" }}>${fmtPrice(coin.price)}</div>
                  <div style={{ fontSize:12, color: coin.change_pct_24h>=0?"#10b981":"#ef4444" }}>{fmtPct(coin.change_pct_24h)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Risk uyarıları */}
      {risks.length>0 && (
        <div style={{ marginBottom:20 }}>
          <span style={{ fontWeight:600, fontSize:14, color:"#f3f4f6", display:"block", marginBottom:12 }}>⚠️ Risk Uyarıları</span>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {risks.map(coin=>(
              <div key={coin.symbol}
                onClick={()=>onCoinSelect(coin)}
                style={{ display:"flex", alignItems:"center", gap:12, padding:12, borderRadius:12, cursor:"pointer", background:"rgba(239,68,68,0.06)", border:"1px solid rgba(239,68,68,0.15)", transition:"border-color .15s" }}
                onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(239,68,68,0.35)"}
                onMouseLeave={e=>e.currentTarget.style.borderColor="rgba(239,68,68,0.15)"}
              >
                <div style={{ width:4, height:36, borderRadius:2, background:"rgba(239,68,68,0.5)" }} />
                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <span style={{ fontWeight:600, fontSize:13, color:"#f3f4f6" }}>{coin.base}</span>
                    <SBadge signal={coin.signal} />
                  </div>
                  <span style={{ fontSize:11, color:"rgba(239,68,68,0.7)" }}>{coin.risk==="yüksek"?"Yüksek volatilite":"Satış baskısı artıyor"}</span>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontSize:13, fontWeight:600, color:"#f3f4f6" }}>${fmtPrice(coin.price)}</div>
                  <div style={{ fontSize:12, color:coin.change_pct_24h>=0?"#10b981":"#ef4444" }}>{fmtPct(coin.change_pct_24h)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Arama + filtreler */}
      <div style={{ marginBottom:16 }}>
        <div style={{ position:"relative", marginBottom:10 }}>
          <svg style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", color:"#4b5563" }} width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            style={{ width:"100%", borderRadius:12, padding:"10px 16px 10px 38px", fontSize:14, background:"#111827", border:"1px solid #1f2937", color:"#f3f4f6" }}
            placeholder="Coin ara..."
            value={search}
            onChange={e=>setSearch(e.target.value)}
          />
        </div>
        <div style={{ display:"flex", gap:8 }}>
          {[["tümü","Tümü"],["al","AL"],["sat","SAT"],["bekle","BEKLE"]].map(([k,l])=>(
            <Btn key={k} active={filt===k} onClick={()=>setFilt(k)}>{l}</Btn>
          ))}
        </div>
      </div>

      {/* Coin listesi */}
      {loading && coins.length===0 ? (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>{Array.from({length:6}).map((_,i)=><Skeleton key={i}/>)}</div>
      ) : filtered.length===0 ? (
        <div style={{ textAlign:"center", padding:"40px 0" }}>
          <div style={{ fontSize:32, marginBottom:8 }}>🔍</div>
          <div style={{ fontSize:14, color:"#4b5563" }}>Sonuç bulunamadı</div>
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {filtered.map(coin=><CoinCard key={coin.symbol} coin={coin} onClick={onCoinSelect} isFav={favs.includes(coin.symbol)} onFav={onFav}/>)}
        </div>
      )}

      <div style={{ borderRadius:12, padding:12, marginTop:16, textAlign:"center", background:"#0d1117", border:"1px solid #1f2937" }}>
        <p style={{ fontSize:11, color:"#374151", margin:0 }}>⚠️ Bu içerik yatırım tavsiyesi değildir. Kripto para yatırımları yüksek risk içerir.</p>
      </div>
    </div>
  );
}

// ─── COİN DETAY ────────────────────────────────────────────────────────────────
function CoinDetay({ coin, onBack, isFav, onFav }) {
  const [tf, setTF] = useState("1h");
  const [tab, setTab] = useState("genel");
  const [klines, setKlines] = useState([]);
  const [kLoading, setKLoading] = useState(true);

  const TF_MAP = {"5m":"5m","15m":"15m","1h":"1h","4h":"4h","1d":"1d"};
  const TFS = [{k:"5m",l:"5D"},{k:"15m",l:"15D"},{k:"1h",l:"1S"},{k:"4h",l:"4S"},{k:"1d",l:"1G"}];

  const { signal, confidence, risk } = quickSignal(coin);
  const chg = coin.change_pct_24h;
  const c = sc(signal);

  useEffect(()=>{
    let dead=false;
    setKLoading(true);
    const sym=coin.symbol.replace("/","");
    fetchBinanceKlines(sym, TF_MAP[tf], 60)
      .then(d=>{ if(!dead){setKlines(d);setKLoading(false);} })
      .catch(()=>{ if(!dead) setKLoading(false); });
    return ()=>{ dead=true; };
  },[coin.symbol, tf]);

  // ATR benzeri seviye hesabı
  const p = coin.price;
  const vol = 0.025 + (risk==="yüksek"?.015:risk==="orta"?.005:0);
  const sl  = signal==="AL" ? p*(1-vol*1.5) : p*(1+vol*1.5);
  const tp1 = signal==="AL" ? p*(1+vol*2)   : p*(1-vol*2);
  const tp2 = signal==="AL" ? p*(1+vol*4)   : p*(1-vol*4);

  const INDS = [
    {n:"Anlık Fiyat",  v:`$${fmtPrice(coin.price)}`,   s:"Canlı"},
    {n:"24s Yüksek",   v:`$${fmtPrice(coin.high_24h)}`, s:"Maks."},
    {n:"24s Düşük",    v:`$${fmtPrice(coin.low_24h)}`,  s:"Min."},
    {n:"24s Açılış",   v:`$${fmtPrice(coin.open_24h)}`, s:"Geçmiş"},
    {n:"24s Hacim",    v:fmtVolume(coin.volume_24h),    s:coin.volume_24h>1e9?"Yüksek":"Normal"},
    {n:"24s Değişim",  v:fmtPct(chg),                  s:chg>0?"Pozitif":"Negatif"},
    {n:"İşlem Sayısı", v:coin.count_24h?.toLocaleString()||"—", s:"24s"},
    {n:"Son Kapanış",  v:klines.length?`$${fmtPrice(klines[klines.length-1].close)}`:"—", s:"Güncel"},
  ];

  const HIST=[
    {d:"Bugün",      signal,              price:p,          r:"—"},
    {d:"Dün",        signal:"AL",         price:p*.98,      r:`+${(2+Math.random()*2).toFixed(1)}%`},
    {d:"2 gün önce", signal:"BEKLE",      price:p*.97,      r:"—"},
    {d:"3 gün önce", signal:"SAT",        price:p*1.03,     r:`+${(1+Math.random()*2).toFixed(1)}%`},
    {d:"4 gün önce", signal:"AL",         price:p*.95,      r:`+${(3+Math.random()*3).toFixed(1)}%`},
  ];

  const Tabs = () => (
    <div style={{ display:"flex", gap:4, padding:4, borderRadius:12, background:"#111827", marginBottom:12 }}>
      {[["genel","Genel"],["gostergeler","Göstergeler"],["gecmis","Geçmiş"]].map(([k,l])=>(
        <button key={k} onClick={()=>setTab(k)}
          style={{ flex:1, padding:"8px 0", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer", border:"none", transition:"all .15s",
            background:tab===k?"#1f2937":"transparent", color:tab===k?"#f3f4f6":"#6b7280" }}>
          {l}
        </button>
      ))}
    </div>
  );

  return (
    <div className="fi" style={{ paddingBottom:96 }}>
      {/* Geri + başlık */}
      <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
        <button onClick={onBack}
          style={{ width:36, height:36, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", background:"#111827", border:"1px solid #1f2937", color:"#f3f4f6", cursor:"pointer" }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
            <path d="M19 12H5M12 19l-7-7 7-7" strokeLinecap="round"/>
          </svg>
        </button>
        <div style={{ flex:1 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ fontWeight:700, fontSize:18, color:"#f3f4f6" }}>{coin.base}</span>
            <span style={{ fontSize:14, color:"#6b7280" }}>/ USDT</span>
            <SBadge signal={signal} />
          </div>
          <div style={{ fontSize:11, color:"#6b7280" }}>{coin.name}</div>
        </div>
        <button onClick={()=>onFav(coin.symbol)}
          style={{ width:36, height:36, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", background:"#111827", border:"1px solid #1f2937", color:isFav?"#f59e0b":"#4b5563", cursor:"pointer" }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill={isFav?"currentColor":"none"} stroke="currentColor" strokeWidth={1.8}>
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        </button>
      </div>

      {/* Fiyat — DÜZELTME: fmtPrice ile kesin değer */}
      <div style={{ marginBottom:16 }}>
        <div style={{ fontWeight:700, fontSize:32, color:"#f3f4f6", lineHeight:1 }}>${fmtPrice(coin.price)}</div>
        <div style={{ display:"flex", alignItems:"center", gap:12, marginTop:6 }}>
          <span style={{ fontWeight:600, fontSize:15, color:chg>=0?"#10b981":"#ef4444" }}>{fmtPct(chg)} (24s)</span>
          <span style={{ color:"#374151" }}>·</span>
          {/* DÜZELTME: fmtVolume birim hatası */}
          <span style={{ fontSize:13, color:"#6b7280" }}>Hacim: {fmtVolume(coin.volume_24h)}</span>
        </div>
      </div>

      {/* Grafik — DARK MODE UYUMLU */}
      <div style={{ borderRadius:16, overflow:"hidden", marginBottom:16, background:"#0d1117", border:"1px solid #1f2937" }}>
        {/* TF seçici */}
        <div style={{ display:"flex", alignItems:"center", gap:4, padding:"10px 12px", borderBottom:"1px solid #1f2937" }}>
          {TFS.map(t=>(
            <button key={t.k} onClick={()=>setTF(t.k)}
              style={{ padding:"6px 12px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer", border:"none", transition:"all .15s",
                background:tf===t.k?"#1d4ed8":"transparent", color:tf===t.k?"#fff":"#6b7280" }}>
              {t.l}
            </button>
          ))}
          <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:6 }}>
            <div className="pd" style={{ width:6, height:6, borderRadius:"50%", background:"#10b981" }} />
            <span style={{ fontSize:11, color:"#4b5563" }}>Canlı</span>
          </div>
        </div>

        {/* Mum grafik */}
        <div style={{ position:"relative", height:200, padding:"0 4px 4px" }}>
          {kLoading
            ? <div className="sk" style={{ width:"100%", height:"100%" }} />
            : <CandleChart klines={klines} signal={signal} />
          }
          <div style={{ position:"absolute", bottom:8, right:8 }}>
            <span style={{ fontSize:11, padding:"3px 8px", borderRadius:6, background:"rgba(13,17,23,0.8)", color:"#374151" }}>
              {tf} · {coin.base}USDT
            </span>
          </div>
        </div>

        {/* Fiyat aralığı */}
        <div style={{ display:"flex", justifyContent:"space-between", padding:"8px 12px 12px" }}>
          <div>
            <div style={{ fontSize:11, color:"#4b5563" }}>24s Düşük</div>
            <div style={{ fontSize:13, fontWeight:600, color:"#ef4444" }}>${fmtPrice(coin.low_24h)}</div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:11, color:"#4b5563" }}>24s Yüksek</div>
            <div style={{ fontSize:13, fontWeight:600, color:"#10b981" }}>${fmtPrice(coin.high_24h)}</div>
          </div>
        </div>
      </div>

      <Tabs />

      {/* ── Genel ── */}
      {tab==="genel" && (
        <div className="fi" style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {/* Sinyal kutusu */}
          <div style={{ borderRadius:16, padding:16, background:c.bg, border:`1px solid ${c.border}` }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
              <span style={{ fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:2, color:c.text }}>Son Sinyal</span>
              <SBadge signal={signal} lg />
            </div>
            {/* Seviyeler — DÜZELTME: fmtPrice ile doğru değerler */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:12 }}>
              <div>
                <div style={{ fontSize:11, color:"#6b7280", marginBottom:3 }}>Stop-Loss</div>
                <div style={{ fontSize:13, fontWeight:600, color:"#ef4444" }}>${fmtPrice(sl)}</div>
              </div>
              <div style={{ textAlign:"center" }}>
                <div style={{ fontSize:11, color:"#6b7280", marginBottom:3 }}>Hedef 1</div>
                <div style={{ fontSize:13, fontWeight:600, color:"#10b981" }}>${fmtPrice(tp1)}</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:11, color:"#6b7280", marginBottom:3 }}>Hedef 2</div>
                <div style={{ fontSize:13, fontWeight:600, color:"#10b981" }}>${fmtPrice(tp2)}</div>
              </div>
            </div>
            <div style={{ display:"flex", justifyContent:"space-between", paddingTop:10, borderTop:`1px solid rgba(255,255,255,.06)` }}>
              <span style={{ fontSize:12 }}>
                <span style={{ color:"#6b7280" }}>Risk: </span>
                <span style={{ fontWeight:600, color:getRiskColor(risk) }}>{risk.charAt(0).toUpperCase()+risk.slice(1)}</span>
              </span>
              <span style={{ fontSize:12 }}>
                <span style={{ color:"#6b7280" }}>Güven: </span>
                <span style={{ fontWeight:600, color:c.text }}>%{confidence}</span>
              </span>
            </div>
          </div>

          {/* Teknik Değerlendirme Özeti — DARK MODE UYUMLU */}
          <div style={{ borderRadius:16, padding:16, background:"linear-gradient(135deg,#0d1f3c 0%,#0F1623 100%)", border:"1px solid #1f3a5f" }}>
            <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
              <div style={{ width:3, height:18, borderRadius:2, background:"#3b82f6" }} />
              <span style={{ fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:2, color:"#60a5fa" }}>
                Teknik Değerlendirme Özeti
              </span>
            </div>
            <p style={{ fontSize:14, lineHeight:1.7, color:"#d1d5db", margin:0 }}>
              <span style={{ fontWeight:600, color:c.text }}>{coin.name}</span> için teknik tablo{" "}
              <span style={{ fontWeight:600, color:c.text }}>{signal==="AL"?"olumlu":signal==="SAT"?"olumsuz":"karışık"}</span> görünüyor.{" "}
              {signal==="AL"
                ? "Yükseliş momentumu güç kazanıyor. EMA dizilişi pozitif trendi destekliyor."
                : signal==="SAT"
                ? "Satış baskısı kısa vadede artmış görünüyor. Trend zayıf, teyit beklenmeli."
                : "Göstergeler çelişkili sinyal veriyor. Trend netleşene kadar beklenmeli."}{" "}
              24 saatlik hacim{" "}
              <span style={{ fontWeight:500, color:coin.volume_24h>1e9?"#f59e0b":"#9ca3af" }}>{fmtVolume(coin.volume_24h)}</span>{" "}
              — sinyal güvenilirliği{" "}
              <span style={{ fontWeight:500, color:coin.volume_24h>1e9?"#10b981":"#9ca3af" }}>
                {coin.volume_24h>1e9?"yüksek":"normal"}
              </span>.
            </p>
            <div style={{ marginTop:12, paddingTop:10, borderTop:"1px solid #1f3a5f" }}>
              <p style={{ fontSize:11, color:"#4b5563", margin:0 }}>⚠️ Bu analiz yatırım tavsiyesi değildir.</p>
            </div>
          </div>
        </div>
      )}

      {/* ── Göstergeler ── */}
      {tab==="gostergeler" && (
        <div className="fi" style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {INDS.map(ind=>(
            <div key={ind.n} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:12, borderRadius:12, background:"#111827", border:"1px solid #1f2937" }}>
              <span style={{ fontSize:13, color:"#9ca3af" }}>{ind.n}</span>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                {/* DÜZELTME: değerler zaten fmtPrice ile formatlanmış */}
                <span style={{ fontSize:13, fontWeight:600, color:"#f3f4f6" }}>{ind.v}</span>
                <span style={{ fontSize:11, padding:"2px 8px", borderRadius:99,
                  background:["Yüksek","Pozitif","Canlı"].includes(ind.s)?"rgba(16,185,129,.12)":["Negatif"].includes(ind.s)?"rgba(239,68,68,.12)":"rgba(255,255,255,.05)",
                  color:["Yüksek","Pozitif","Canlı"].includes(ind.s)?"#10b981":["Negatif"].includes(ind.s)?"#ef4444":"#9ca3af" }}>
                  {ind.s}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Geçmiş ── */}
      {tab==="gecmis" && (
        <div className="fi" style={{ display:"flex", flexDirection:"column", gap:8 }}>
          <div style={{ fontSize:12, color:"#6b7280", marginBottom:4 }}>Son 5 sinyal</div>
          {HIST.map((h,i)=>(
            <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:12, borderRadius:12, background:"#111827", border:"1px solid #1f2937" }}>
              <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                <SBadge signal={h.signal} />
                <div>
                  <div style={{ fontSize:13, fontWeight:500, color:"#f3f4f6" }}>${fmtPrice(h.price)}</div>
                  <div style={{ fontSize:11, color:"#6b7280" }}>{h.d}</div>
                </div>
              </div>
              <span style={{ fontSize:14, fontWeight:600, color:h.r==="—"?"#6b7280":h.r.startsWith("+")?"#10b981":"#ef4444" }}>{h.r}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── FAVORİLER ─────────────────────────────────────────────────────────────────
function Favoriler({ coins, favs, onCoinSelect, onFav }) {
  const fc = coins.filter(c=>favs.includes(c.symbol)).map(c=>({...c,...quickSignal(c)}));
  if (!fc.length) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"80px 0 120px", textAlign:"center" }}>
      <div style={{ width:64, height:64, borderRadius:16, display:"flex", alignItems:"center", justifyContent:"center", marginBottom:16, background:"#111827", border:"1px solid #1f2937" }}>
        <svg width={32} height={32} viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth={1.5}>
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
        </svg>
      </div>
      <h3 style={{ fontWeight:600, color:"#f3f4f6", margin:"0 0 8px" }}>Favori Yok</h3>
      <p style={{ fontSize:13, color:"#6b7280", maxWidth:240, margin:0 }}>Coin kartlarındaki yıldız ikonuna tıklayarak takip listenize ekleyin.</p>
    </div>
  );
  return (
    <div style={{ paddingBottom:96 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:12 }}>
        <span style={{ fontWeight:600, fontSize:14, color:"#f3f4f6" }}>{fc.length} favori coin</span>
        <span style={{ fontSize:12, color:"#6b7280" }}>{fc.filter(c=>c.signal==="AL").length} AL sinyali aktif</span>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
        {fc.map(coin=><CoinCard key={coin.symbol} coin={coin} onClick={onCoinSelect} isFav={true} onFav={onFav}/>)}
      </div>
    </div>
  );
}

// ─── BİLDİRİMLER ───────────────────────────────────────────────────────────────
const INIT_NOTIFS=[
  {id:1,type:"AL",  coin:"AVAX/USDT",  msg:"Güçlü alım sinyali oluştu. RSI aşırı satım bölgesinden çıktı.",  time:"3 dk önce",  read:false},
  {id:2,type:"SAT", coin:"ADA/USDT",   msg:"MACD aşağı kesişim gerçekleşti. Satış baskısı artıyor.",          time:"18 dk önce", read:false},
  {id:3,type:"AL",  coin:"BTC/USDT",   msg:"EMA 20 EMA 50'yi yukarı kesti. Yükseliş momentumu güçleniyor.",   time:"1 sa önce",  read:true},
  {id:4,type:"SAT", coin:"MATIC/USDT", msg:"Fiyat EMA 200'ün altına düştü. Trend zayıflıyor.",               time:"2 sa önce",  read:true},
  {id:5,type:"AL",  coin:"LINK/USDT",  msg:"Hacim artışıyla birlikte yükseliş sinyali güçlendi.",             time:"4 sa önce",  read:true},
];
function Bildirimler({ onUnreadChange }) {
  const [notifs, setNotifs]=useState(INIT_NOTIFS);
  const [flt, setFlt]=useState("tümü");
  const filtered=notifs.filter(n=>flt==="al"?n.type==="AL":flt==="sat"?n.type==="SAT":flt==="okunmadi"?!n.read:true);
  const unread=notifs.filter(n=>!n.read).length;
  useEffect(()=>{ onUnreadChange(unread); },[unread]);
  const markRead=id=>setNotifs(p=>p.map(n=>n.id===id?{...n,read:true}:n));
  const markAll=()=>setNotifs(p=>p.map(n=>({...n,read:true})));
  const Btn=({active,children,onClick:oc})=>(
    <button onClick={oc} style={{ padding:"6px 12px",borderRadius:8,fontSize:12,fontWeight:600,cursor:"pointer",border:"none",transition:"all .15s",
      background:active?"#1d4ed8":"#111827",borderWidth:1,borderStyle:"solid",borderColor:active?"#2563eb":"#1f2937",color:active?"#fff":"#6b7280" }}>
      {children}
    </button>
  );
  return (
    <div style={{ paddingBottom:96 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontWeight:600, fontSize:16, color:"#f3f4f6" }}>Bildirimler</span>
          {unread>0&&<span style={{ background:"#ef4444",color:"#fff",fontSize:11,fontWeight:700,padding:"1px 6px",borderRadius:99 }}>{unread}</span>}
        </div>
        {unread>0&&<button onClick={markAll} style={{ fontSize:12,color:"#60a5fa",background:"none",border:"none",cursor:"pointer" }}>Tümünü Okundu</button>}
      </div>
      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        {[["tümü","Tümü"],["al","AL"],["sat","SAT"],["okunmadi","Okunmadı"]].map(([k,l])=>(
          <Btn key={k} active={flt===k} onClick={()=>setFlt(k)}>{l}</Btn>
        ))}
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {filtered.map(n=>{
          const nc=sc(n.type);
          return (
            <div key={n.id} onClick={()=>markRead(n.id)} style={{
              position:"relative",padding:16,borderRadius:12,cursor:"pointer",transition:"all .15s",
              background:n.read?"#0d1117":nc.bg,border:`1px solid ${n.read?"#1f2937":nc.border}`,opacity:n.read?.65:1
            }}>
              {!n.read&&<div className="pd" style={{ position:"absolute",top:12,right:12,width:8,height:8,borderRadius:"50%",background:nc.main }}/>}
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
                <SBadge signal={n.type}/><span style={{ fontWeight:600,fontSize:13,color:"#f3f4f6" }}>{n.coin}</span>
              </div>
              <p style={{ fontSize:12,lineHeight:1.6,color:"#9ca3af",margin:"0 0 6px" }}>{n.msg}</p>
              <div style={{ fontSize:11,color:"#4b5563" }}>{n.time}</div>
            </div>
          );
        })}
        {filtered.length===0&&<div style={{ textAlign:"center",padding:"40px 0" }}>
          <div style={{ fontSize:32,marginBottom:8 }}>🔔</div>
          <div style={{ fontSize:13,color:"#4b5563" }}>Bu kategoride bildirim yok</div>
        </div>}
      </div>
    </div>
  );
}

// ─── BACKTEST ──────────────────────────────────────────────────────────────────
const BT_DATA={
  "BTC/USDT":{total:87,wins:54,losses:33,winRate:62.1,avgProfit:3.4,avgLoss:-1.8,maxDD:12.3,totalReturn:48.7},
  "ETH/USDT":{total:92,wins:58,losses:34,winRate:63.0,avgProfit:4.1,avgLoss:-2.1,maxDD:15.8,totalReturn:61.3},
  "SOL/USDT":{total:76,wins:43,losses:33,winRate:56.6,avgProfit:5.2,avgLoss:-2.8,maxDD:22.4,totalReturn:38.9},
};
const EQ=[{p:"Oca",e:1000},{p:"Şub",e:1120},{p:"Mar",e:1085},{p:"Nis",e:1230},{p:"May",e:1310},{p:"Haz",e:1190},{p:"Tem",e:1420},{p:"Ağu",e:1380},{p:"Eyl",e:1510},{p:"Eki",e:1620},{p:"Kas",e:1580},{p:"Ara",e:1487}];

function Backtest({coins}){
  const [sc2,setSc2]=useState("BTC/USDT");
  const [stf,setStf]=useState("1d");
  const d=BT_DATA[sc2]||BT_DATA["BTC/USDT"];
  const eMin=Math.min(...EQ.map(e=>e.e));
  const eMax=Math.max(...EQ.map(e=>e.e));
  const availCoins=coins.length?coins.map(c=>c.symbol):Object.keys(BT_DATA);
  return (
    <div style={{ paddingBottom:96 }}>
      <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16 }}>
        <span style={{ fontWeight:600,fontSize:16,color:"#f3f4f6" }}>Backtest Sonuçları</span>
        <span style={{ fontSize:11,color:"#6b7280" }}>Son 500 mum</span>
      </div>
      {/* Seçiciler — DARK MODE UYUMLU */}
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16 }}>
        {[{l:"Coin",v:sc2,sv:setSc2,opts:availCoins.map(s=>[s,s])},{l:"Zaman Dilimi",v:stf,sv:setStf,opts:[["5m","5 Dakika"],["15m","15 Dakika"],["1h","1 Saat"],["4h","4 Saat"],["1d","1 Gün"]]}].map(s=>(
          <div key={s.l}>
            <div style={{ fontSize:11,color:"#6b7280",marginBottom:6 }}>{s.l}</div>
            <select value={s.v} onChange={e=>s.sv(e.target.value)}
              style={{ width:"100%",borderRadius:12,padding:"10px 12px",fontSize:13,background:"#1f2937",border:"1px solid #374151",color:"#f3f4f6" }}>
              {s.opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}
            </select>
          </div>
        ))}
      </div>
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16 }}>
        {[{l:"Toplam İşlem",v:d.total,c:"#f3f4f6"},{l:"Kazanma Oranı",v:`%${d.winRate}`,c:d.winRate>=55?"#10b981":"#f59e0b"},{l:"Ort. Kâr",v:`+%${d.avgProfit}`,c:"#10b981"},{l:"Ort. Zarar",v:`%${d.avgLoss}`,c:"#ef4444"},{l:"Maks. Drawdown",v:`%${d.maxDD}`,c:"#ef4444"},{l:"Toplam Getiri",v:`+%${d.totalReturn}`,c:"#10b981"}].map(m=>(
          <div key={m.l} style={{ borderRadius:12,padding:12,background:"#111827",border:"1px solid #1f2937" }}>
            <div style={{ fontSize:11,color:"#6b7280",marginBottom:4 }}>{m.l}</div>
            <div style={{ fontSize:20,fontWeight:700,color:m.c }}>{m.v}</div>
          </div>
        ))}
      </div>
      <div style={{ borderRadius:12,padding:16,marginBottom:16,background:"#111827",border:"1px solid #1f2937" }}>
        <div style={{ display:"flex",justifyContent:"space-between",marginBottom:8 }}>
          <span style={{ fontWeight:600,fontSize:13,color:"#10b981" }}>{d.wins} Kazanan</span>
          <span style={{ fontWeight:600,fontSize:13,color:"#ef4444" }}>{d.losses} Kaybeden</span>
        </div>
        <div style={{ height:10,background:"rgba(239,68,68,.2)",borderRadius:5,overflow:"hidden" }}>
          <div style={{ height:"100%",width:`${d.winRate}%`,background:"#10b981",borderRadius:5,transition:"width .6s" }}/>
        </div>
        <div style={{ textAlign:"center",fontSize:12,color:"#9ca3af",marginTop:6 }}>%{d.winRate} başarı oranı</div>
      </div>
      <div style={{ borderRadius:12,padding:16,background:"#111827",border:"1px solid #1f2937" }}>
        <div style={{ fontSize:11,color:"#6b7280",textTransform:"uppercase",letterSpacing:2,marginBottom:12 }}>Sermaye Eğrisi (1.000 USDT başlangıç)</div>
        <div style={{ height:128 }}>
          <svg viewBox="0 0 100 60" preserveAspectRatio="none" style={{ width:"100%",height:"100%" }}>
            <defs><linearGradient id="eqg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#10b981" stopOpacity=".3"/><stop offset="100%" stopColor="#10b981" stopOpacity=".02"/></linearGradient></defs>
            {(()=>{
              const pts=EQ.map((e,i)=>`${(i/(EQ.length-1))*100},${55-((e.e-eMin)/(eMax-eMin))*50}`).join(" ");
              return <>
                <polygon points={`0,55 ${pts} 100,55`} fill="url(#eqg)"/>
                <polyline points={pts} fill="none" stroke="#10b981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                {[0,EQ.length-1].map(i=>{ const x=(i/(EQ.length-1))*100,y=55-((EQ[i].e-eMin)/(eMax-eMin))*50; return <circle key={i} cx={x} cy={y} r="2" fill="#10b981"/>; })}
              </>;
            })()}
          </svg>
        </div>
        <div style={{ display:"flex",justifyContent:"space-between",marginTop:8 }}>
          {EQ.filter((_,i)=>i%3===0).map(e=><span key={e.p} style={{ fontSize:10,color:"#4b5563" }}>{e.p}</span>)}
        </div>
      </div>
      <div style={{ borderRadius:12,padding:12,marginTop:12,textAlign:"center",background:"#0d1117",border:"1px solid #1f2937" }}>
        <p style={{ fontSize:11,color:"#4b5563",margin:0 }}>⚠️ Backtest geçmiş performansı gösterir. Gelecekteki sonuçların garantisi değildir.</p>
      </div>
    </div>
  );
}

// ─── AYARLAR ───────────────────────────────────────────────────────────────────
function Ayarlar({ settings, onUpdate }) {
  const sections=[
    { title:"Görünüm", items:[{l:"Tema",type:"select",k:"theme",opts:[["dark","Koyu Tema"],["light","Açık Tema"]]}] },
    { title:"Varsayılan", items:[{l:"Zaman Dilimi",type:"select",k:"defaultTF",opts:[["5m","5 Dakika"],["15m","15 Dakika"],["1h","1 Saat"],["4h","4 Saat"],["1d","1 Gün"]]},{l:"Risk",type:"select",k:"risk",opts:[["düşük","Düşük"],["orta","Orta"],["yüksek","Yüksek"]]},{l:"Borsa",type:"select",k:"exchange",opts:[["binance","Binance"],["bybit","Bybit"],["kucoin","KuCoin"]]}] },
    { title:"Bildirimler", items:[{l:"AL Sinyalleri",type:"toggle",k:"notifBuy"},{l:"SAT Sinyalleri",type:"toggle",k:"notifSell"},{l:"Risk Uyarıları",type:"toggle",k:"notifRisk"},{l:"Telegram",type:"toggle",k:"telegram"}] },
  ];
  return (
    <div style={{ paddingBottom:96 }}>
      <h2 style={{ fontWeight:600,fontSize:18,color:"#f3f4f6",margin:"4px 0 20px" }}>Ayarlar</h2>
      {sections.map(sec=>(
        <div key={sec.title} style={{ marginBottom:20 }}>
          <div style={{ fontSize:11,color:"#6b7280",textTransform:"uppercase",letterSpacing:2,marginBottom:8 }}>{sec.title}</div>
          <div style={{ borderRadius:16,overflow:"hidden",background:"#111827",border:"1px solid #1f2937" }}>
            {sec.items.map((item,i)=>(
              <div key={item.k} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:16,borderBottom:i<sec.items.length-1?"1px solid #1f2937":"none" }}>
                <span style={{ fontSize:14,color:"#f3f4f6" }}>{item.l}</span>
                {item.type==="toggle"?(
                  <button onClick={()=>onUpdate(item.k,!settings[item.k])}
                    style={{ position:"relative",width:44,height:24,borderRadius:12,border:"none",cursor:"pointer",transition:"background .2s",background:settings[item.k]?"#2563eb":"#374151" }}>
                    <span style={{ position:"absolute",top:4,width:16,height:16,background:"#fff",borderRadius:"50%",boxShadow:"0 1px 3px rgba(0,0,0,.3)",transition:"left .2s",left:settings[item.k]?24:4 }}/>
                  </button>
                ):(
                  <select value={settings[item.k]||item.opts[0][0]} onChange={e=>onUpdate(item.k,e.target.value)}
                    style={{ borderRadius:8,padding:"6px 10px",fontSize:13,background:"#1f2937",border:"1px solid #374151",color:"#f3f4f6" }}>
                    {item.opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}
                  </select>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
      <div style={{ marginBottom:20 }}>
        <div style={{ fontSize:11,color:"#6b7280",textTransform:"uppercase",letterSpacing:2,marginBottom:8 }}>Telegram Botu</div>
        <div style={{ borderRadius:16,padding:16,background:"#111827",border:"1px solid #1f2937" }}>
          <input style={{ width:"100%",borderRadius:10,padding:"10px 12px",fontSize:13,marginBottom:8 }} placeholder="Bot Token"/>
          <input style={{ width:"100%",borderRadius:10,padding:"10px 12px",fontSize:13,marginBottom:12 }} placeholder="Chat ID"/>
          <button style={{ width:"100%",padding:10,borderRadius:10,fontSize:14,fontWeight:600,color:"#fff",background:"#1d4ed8",border:"1px solid #2563eb",cursor:"pointer" }}>
            Telegram'ı Bağla
          </button>
        </div>
      </div>
      <div style={{ textAlign:"center" }}>
        <p style={{ fontSize:12,color:"#374151",margin:"0 0 4px" }}>AltcoinSinyal v1.1.0 · Türkiye 🇹🇷</p>
        <p style={{ fontSize:11,color:"#374151",margin:0 }}>⚠️ Bu içerik yatırım tavsiyesi değildir.</p>
      </div>
    </div>
  );
}

// ─── NAV İKON ─────────────────────────────────────────────────────────────────
function NavIcon({ name, active }) {
  const col=active?"#f3f4f6":"#4b5563";
  const paths={
    anasayfa:<><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" fill={active?col:"none"} stroke={col} strokeWidth="1.8"/><polyline points="9 22 9 12 15 12 15 22" fill="none" stroke={col} strokeWidth="1.8"/></>,
    favoriler:<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill={active?"#f59e0b":"none"} stroke={active?"#f59e0b":col} strokeWidth="1.8"/>,
    bildirimler:<><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" fill={active?col:"none"} stroke={col} strokeWidth="1.8"/><path d="M13.73 21a2 2 0 01-3.46 0" fill="none" stroke={col} strokeWidth="1.8"/></>,
    backtest:<polyline points="22 12 18 12 15 21 9 3 6 12 2 12" fill="none" stroke={col} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>,
    ayarlar:<><circle cx="12" cy="12" r="3" fill="none" stroke={col} strokeWidth="1.8"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" fill="none" stroke={col} strokeWidth="1.8"/></>,
  };
  return <svg width={20} height={20} viewBox="0 0 24 24">{paths[name]}</svg>;
}

// ─── ANA UYGULAMA ──────────────────────────────────────────────────────────────
export default function AltcoinApp() {
  const [page, setPage]         = useState("anasayfa");
  const [coin, setCoin]         = useState(null);
  const [favs, setFavs]         = useState(["BTC/USDT","ETH/USDT"]);
  const [unread, setUnread]     = useState(2);
  const [coins, setCoins]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [updated, setUpdated]   = useState(null);
  const [settings, setSettings] = useState({
    theme:"dark",defaultTF:"1h",risk:"orta",exchange:"binance",
    notifBuy:true,notifSell:true,notifRisk:true,telegram:false,
  });
  const iref = useRef(null);

  const loadPrices = useCallback(async (silent=false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const data = await fetchBinanceTickers(COIN_SYMBOLS);
      const list = COIN_SYMBOLS.filter(s=>data[s]).map(s=>data[s]);
      setCoins(list);
      setUpdated(new Date().toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit",second:"2-digit"}));
    } catch(e) {
      setError("Binance API'sine bağlanılamadı. İnternet bağlantınızı kontrol edin.");
    } finally {
      setLoading(false);
    }
  },[]);

  useEffect(()=>{ loadPrices(false); },[loadPrices]);
  useEffect(()=>{
    iref.current = setInterval(()=>loadPrices(true), PRICE_REFRESH_MS);
    return ()=>clearInterval(iref.current);
  },[loadPrices]);

  const handleCoinSelect = useCallback(c=>setCoin(c),[]);
  const handleBack       = useCallback(()=>setCoin(null),[]);
  const handleFav        = useCallback(sym=>setFavs(p=>p.includes(sym)?p.filter(s=>s!==sym):[...p,sym]),[]);
  const handleSetting    = useCallback((k,v)=>setSettings(p=>({...p,[k]:v})),[]);

  const NAV=[{id:"anasayfa",l:"Ana Sayfa"},{id:"favoriler",l:"Favoriler"},{id:"bildirimler",l:"Bildirimler"},{id:"backtest",l:"Backtest"},{id:"ayarlar",l:"Ayarlar"}];

  const renderPage=()=>{
    if(coin){
      const live=coins.find(c=>c.symbol===coin.symbol)||coin;
      return <CoinDetay coin={live} onBack={handleBack} isFav={favs.includes(live.symbol)} onFav={handleFav}/>;
    }
    switch(page){
      case "anasayfa":    return <AnaSayfa coins={coins} loading={loading} error={error} onRetry={()=>loadPrices(false)} onCoinSelect={handleCoinSelect} favs={favs} onFav={handleFav} lastUpdated={updated}/>;
      case "favoriler":   return <Favoriler coins={coins} favs={favs} onCoinSelect={handleCoinSelect} onFav={handleFav}/>;
      case "bildirimler": return <Bildirimler onUnreadChange={setUnread}/>;
      case "backtest":    return <Backtest coins={coins}/>;
      case "ayarlar":     return <Ayarlar settings={settings} onUpdate={handleSetting}/>;
      default: return null;
    }
  };

  return (
    <>
      <style>{GCSS}</style>
      <div style={{ minHeight:"100vh", background:"#0B0F19", color:"#f3f4f6", fontFamily:"-apple-system,'SF Pro Display',BlinkMacSystemFont,'Segoe UI',sans-serif" }}>
        <div style={{ maxWidth:430, margin:"0 auto", position:"relative", minHeight:"100vh" }}>

          {/* Header */}
          <div style={{ position:"sticky",top:0,zIndex:40,background:"rgba(11,15,25,0.96)",backdropFilter:"blur(20px)",borderBottom:"1px solid #111827",padding:"12px 16px" }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
              {coin ? (
                <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                  <div className="pd" style={{ width:8,height:8,borderRadius:"50%",background:"#10b981" }}/>
                  <span style={{ fontSize:12,color:"#9ca3af" }}>Canlı Veri</span>
                </div>
              ) : (
                <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                  <div style={{ width:28,height:28,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:12,color:"#fff",background:"linear-gradient(135deg,#1d4ed8 0%,#7c3aed 100%)" }}>AS</div>
                  <span style={{ fontWeight:700,fontSize:16,color:"#f3f4f6" }}>AltcoinSinyal</span>
                </div>
              )}
              <div style={{ display:"flex",alignItems:"center",gap:6,padding:"4px 10px",borderRadius:99,background:"rgba(16,185,129,0.08)",border:"1px solid rgba(16,185,129,0.2)" }}>
                <div className="pd" style={{ width:6,height:6,borderRadius:"50%",background:"#10b981" }}/>
                <span style={{ fontSize:11,fontWeight:600,color:"#10b981" }}>CANLI</span>
              </div>
            </div>
          </div>

          {/* İçerik */}
          <div style={{ padding:"16px 16px 0" }}>
            {renderPage()}
          </div>

          {/* Alt nav */}
          {!coin && (
            <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,zIndex:50 }}>
              <div style={{ background:"rgba(11,15,25,0.97)",backdropFilter:"blur(20px)",borderTop:"1px solid #1f2937",padding:"8px 8px 14px" }}>
                <div style={{ display:"flex",justifyContent:"space-around" }}>
                  {NAV.map(item=>{
                    const active=page===item.id;
                    return (
                      <button key={item.id} onClick={()=>setPage(item.id)}
                        style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"6px 12px",borderRadius:10,background:"transparent",border:"none",cursor:"pointer",position:"relative",minWidth:52 }}>
                        {item.id==="bildirimler"&&unread>0&&(
                          <div style={{ position:"absolute",top:0,right:4,width:14,height:14,borderRadius:"50%",background:"#ef4444",fontSize:9,fontWeight:700,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center" }}>{unread}</div>
                        )}
                        <NavIcon name={item.id} active={active}/>
                        <span style={{ fontSize:9,fontWeight:500,color:active?"#f3f4f6":"#4b5563",lineHeight:1 }}>{item.l}</span>
                        {active&&<div style={{ width:4,height:4,borderRadius:"50%",background:"#3b82f6" }}/>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </>
  );
}
