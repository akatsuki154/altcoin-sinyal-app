/**
 * API istemci — production-ready, localhost kullanılmaz.
 * URL kaynağı: NEXT_PUBLIC_API_BASE_URL (Vercel env variable)
 */

const RAW = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";

if (!RAW && typeof window !== "undefined") {
  console.warn(
    "[AltcoinSinyal] NEXT_PUBLIC_API_BASE_URL tanımlı değil. " +
    "Vercel → Settings → Environment Variables bölümüne ekleyin."
  );
}

export const API_BASE = RAW.replace(/\/$/, "");

// ── Tipler ────────────────────────────────────────────────────────────────────

export interface CoinData {
  symbol:         string;
  binance_symbol: string;
  base:           string;
  quote:          string;
  name:           string;
  price:          number;
  open_24h:       number;
  high_24h:       number;
  low_24h:        number;
  volume_24h:     number;
  change_24h:     number;
  change_pct_24h: number;
  count_24h:      number;
}

export interface Candle {
  time:   number;
  open:   number;
  high:   number;
  low:    number;
  close:  number;
  volume: number;
}

interface Envelope<T> {
  ok:     boolean;
  data:   T;
  count?: number;
  error?: string;
}

// ── Hata ──────────────────────────────────────────────────────────────────────

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

// ── Fetch wrapper ─────────────────────────────────────────────────────────────

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path.startsWith("/") ? path : `/${path}`}`;
  let res: Response;
  try {
    res = await fetch(url, { ...init, headers: { "Content-Type": "application/json", ...init?.headers } });
  } catch (err) {
    throw new ApiError(0,
      `Backend'e ulaşılamıyor. URL: ${url} | ` +
      `NEXT_PUBLIC_API_BASE_URL: "${API_BASE || "BOŞ"}" | ` +
      `Hata: ${(err as Error).message}`
    );
  }
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try { const b = await res.json(); detail = b?.detail ?? detail; } catch {}
    throw new ApiError(res.status, detail);
  }
  return res.json() as Promise<T>;
}

// ── API fonksiyonları ─────────────────────────────────────────────────────────

export async function fetchTicker(symbol: string): Promise<CoinData> {
  const r = await apiFetch<Envelope<CoinData>>(`/api/ticker/${encodeURIComponent(symbol)}`);
  return r.data;
}

export async function fetchTickers(symbols: string[]): Promise<CoinData[]> {
  const r = await apiFetch<Envelope<CoinData[]>>(
    `/api/tickers?symbols=${encodeURIComponent(symbols.join(","))}`
  );
  return r.data;
}

export async function fetchOHLCV(symbol: string, timeframe = "1h", limit = 200): Promise<Candle[]> {
  const r = await apiFetch<Envelope<Candle[]>>(
    `/api/ohlcv/${encodeURIComponent(symbol)}?timeframe=${timeframe}&limit=${limit}`
  );
  return r.data;
}

export async function fetchHealth() {
  return apiFetch<{ status: string; uptime_seconds: number }>("/health");
}
