from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    APP_ENV: str = "production"
    LOG_LEVEL: str = "INFO"

    DEFAULT_EXCHANGE: str = "binance"
    EXCHANGE_TIMEOUT: int = 10000
    ENABLE_RATE_LIMIT: bool = True

    # Deploy sonrası Vercel URL'si buraya gelir.
    # Render/Railway dashboard'da environment variable olarak set edilir.
    CORS_ORIGINS: List[str] = []

    BINANCE_API_KEY: str = ""
    BINANCE_SECRET: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()
