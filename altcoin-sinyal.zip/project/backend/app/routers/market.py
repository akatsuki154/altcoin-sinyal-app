import logging
from fastapi import APIRouter, Query
from app.services.exchange import fetch_ticker, fetch_tickers_bulk, fetch_ohlcv

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/ticker/{symbol}")
async def get_ticker(symbol: str):
    """
    Tek sembol ticker.
    GET /api/ticker/BTCUSDT
    GET /api/ticker/BTC%2FUSDT
    """
    data = await fetch_ticker(symbol)
    return {"ok": True, "data": data}


@router.get("/tickers")
async def get_tickers(
    symbols: str = Query(
        ...,
        description="Virgülle ayrılmış semboller: BTCUSDT,ETHUSDT,SOLUSDT",
        example="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,ADAUSDT",
    ),
):
    """
    Çoklu sembol ticker — tek API çağrısı.
    GET /api/tickers?symbols=BTCUSDT,ETHUSDT,SOLUSDT
    """
    symbol_list = [s.strip() for s in symbols.split(",") if s.strip()]
    if not symbol_list:
        return {"ok": False, "error": "En az bir sembol gerekli.", "data": []}
    if len(symbol_list) > 50:
        return {"ok": False, "error": "En fazla 50 sembol sorgulanabilir.", "data": []}

    data = await fetch_tickers_bulk(symbol_list)
    return {"ok": True, "count": len(data), "data": data}


@router.get("/ohlcv/{symbol}")
async def get_ohlcv(
    symbol: str,
    timeframe: str = Query(default="1h", description="1m,5m,15m,1h,4h,1d"),
    limit: int = Query(default=200, ge=1, le=1000),
):
    """
    OHLCV mum verisi.
    GET /api/ohlcv/BTCUSDT?timeframe=1h&limit=200
    """
    data = await fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    return {"ok": True, "symbol": symbol, "timeframe": timeframe, "count": len(data), "data": data}
