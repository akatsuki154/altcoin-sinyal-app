import time
import logging
from fastapi import APIRouter
from app.services.exchange import get_exchange

logger = logging.getLogger(__name__)
router = APIRouter()

_START = time.time()


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "uptime_seconds": round(time.time() - _START, 1),
        "service": "AltcoinSinyal API",
    }


@router.get("/health/exchange")
async def exchange_health():
    exchange = get_exchange()
    t0 = time.time()
    try:
        await exchange.fetch_time()
        return {
            "status": "ok",
            "exchange": "binance",
            "latency_ms": round((time.time() - t0) * 1000, 1),
        }
    except Exception as exc:
        logger.error(f"Exchange ping başarısız: {exc}")
        return {"status": "error", "exchange": "binance", "detail": str(exc)}
