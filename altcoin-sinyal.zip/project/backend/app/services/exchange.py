"""
Binance bağlantı servisi — ccxt async wrapper.

- Exchange singleton: her istek için yeniden oluşturulmaz
- Symbol normalizasyonu: BTCUSDT → BTC/USDT
- Hata yönetimi: NetworkError, ExchangeError, BadSymbol, Timeout, RateLimit
- enableRateLimit: True (ccxt kendi rate limitini yönetir)
- timeout: config'den okunur
"""

import logging
import ccxt.async_support as ccxt
from ccxt.base.errors import (
    NetworkError,
    ExchangeError,
    BadSymbol,
    RequestTimeout,
    RateLimitExceeded,
)
from fastapi import HTTPException
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

VALID_TIMEFRAMES = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d", "1w"}

_exchange: ccxt.Exchange | None = None


def _build_exchange() -> ccxt.Exchange:
    config: dict = {
        "enableRateLimit": settings.ENABLE_RATE_LIMIT,
        "timeout": settings.EXCHANGE_TIMEOUT,
        "options": {
            "defaultType": "spot",
            "adjustForTimeDifference": True,
        },
    }
    if settings.BINANCE_API_KEY and settings.BINANCE_SECRET:
        config["apiKey"] = settings.BINANCE_API_KEY
        config["secret"] = settings.BINANCE_SECRET

    return ccxt.binance(config)


def get_exchange() -> ccxt.Exchange:
    global _exchange
    if _exchange is None:
        _exchange = _build_exchange()
        logger.info("Binance exchange instance oluşturuldu.")
    return _exchange


async def close_exchange() -> None:
    global _exchange
    if _exchange is not None:
        await _exchange.close()
        _exchange = None
        logger.info("Binance bağlantısı kapatıldı.")


def normalize_symbol(raw: str) -> str:
    """
    BTCUSDT → BTC/USDT
    BTC/USDT → BTC/USDT  (değişmez)
    btcusdt  → BTC/USDT
    BTC-USDT → BTC/USDT
    """
    s = raw.strip().upper().replace("-", "/")
    if "/" in s:
        return s
    # Uzundan kısaya sırala — çakışmayı önler (USDC önce USDT'den önce kontrol edilmeli değil, USDT daha uzun)
    quotes = ["USDT", "USDC", "BUSD", "FDUSD", "BTC", "ETH", "BNB", "TRY"]
    for quote in quotes:
        if s.endswith(quote) and len(s) > len(quote):
            base = s[: -len(quote)]
            return f"{base}/{quote}"
    logger.warning(f"Sembol normalize edilemedi: {raw!r}")
    return s


def _raise_http(exc: Exception, symbol: str = "") -> None:
    """ccxt hatalarını HTTP hatalarına dönüştür."""
    ctx = f" [{symbol}]" if symbol else ""
    if isinstance(exc, BadSymbol):
        raise HTTPException(400, f"Geçersiz sembol{ctx}. Örnek: BTC/USDT veya BTCUSDT")
    if isinstance(exc, RateLimitExceeded):
        raise HTTPException(429, "Binance rate limit aşıldı. Birkaç saniye bekleyin.")
    if isinstance(exc, RequestTimeout):
        raise HTTPException(504, f"Binance bağlantısı zaman aşımına uğradı{ctx}.")
    if isinstance(exc, NetworkError):
        raise HTTPException(503, f"Borsa bağlantısı kurulamadı{ctx}.")
    if isinstance(exc, ExchangeError):
        raise HTTPException(502, f"Borsa hatası{ctx}: {exc}")
    logger.exception(f"Bilinmeyen hata{ctx}: {exc}")
    raise HTTPException(500, "Sunucu hatası.")


async def fetch_ticker(symbol_raw: str) -> dict:
    symbol = normalize_symbol(symbol_raw)
    exchange = get_exchange()
    try:
        t = await exchange.fetch_ticker(symbol)
    except (BadSymbol, RateLimitExceeded, RequestTimeout, NetworkError, ExchangeError) as e:
        _raise_http(e, symbol)

    return {
        "symbol":         symbol,
        "binance_symbol": symbol.replace("/", ""),
        "base":           symbol.split("/")[0],
        "quote":          symbol.split("/")[1] if "/" in symbol else "USDT",
        "name":           symbol.split("/")[0],
        "price":          float(t["last"] or 0),
        "open_24h":       float(t["open"] or 0),
        "high_24h":       float(t["high"] or 0),
        "low_24h":        float(t["low"] or 0),
        "volume_24h":     float(t["quoteVolume"] or 0),
        "change_24h":     float(t["change"] or 0),
        "change_pct_24h": float(t["percentage"] or 0),
        "count_24h":      int(t.get("info", {}).get("count", 0) or 0),
    }


async def fetch_tickers_bulk(symbols_raw: list[str]) -> list[dict]:
    exchange = get_exchange()
    normalized = [normalize_symbol(s) for s in symbols_raw]
    try:
        all_tickers = await exchange.fetch_tickers(normalized)
    except (NetworkError, ExchangeError, RequestTimeout, RateLimitExceeded) as e:
        _raise_http(e)

    results = []
    for symbol in normalized:
        t = all_tickers.get(symbol)
        if not t:
            continue
        results.append({
            "symbol":         symbol,
            "binance_symbol": symbol.replace("/", ""),
            "base":           symbol.split("/")[0],
            "quote":          symbol.split("/")[1] if "/" in symbol else "USDT",
            "name":           symbol.split("/")[0],
            "price":          float(t["last"] or 0),
            "open_24h":       float(t["open"] or 0),
            "high_24h":       float(t["high"] or 0),
            "low_24h":        float(t["low"] or 0),
            "volume_24h":     float(t["quoteVolume"] or 0),
            "change_24h":     float(t["change"] or 0),
            "change_pct_24h": float(t["percentage"] or 0),
            "count_24h":      int(t.get("info", {}).get("count", 0) or 0),
        })
    return results


async def fetch_ohlcv(symbol_raw: str, timeframe: str = "1h", limit: int = 200) -> list[dict]:
    if timeframe not in VALID_TIMEFRAMES:
        raise HTTPException(
            400,
            f"Geçersiz zaman dilimi: {timeframe!r}. Geçerliler: {sorted(VALID_TIMEFRAMES)}",
        )
    limit = max(1, min(limit, 1000))
    symbol = normalize_symbol(symbol_raw)
    exchange = get_exchange()
    try:
        raw = await exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    except (BadSymbol, RateLimitExceeded, RequestTimeout, NetworkError, ExchangeError) as e:
        _raise_http(e, symbol)

    return [
        {
            "time":   int(row[0]),
            "open":   float(row[1]),
            "high":   float(row[2]),
            "low":    float(row[3]),
            "close":  float(row[4]),
            "volume": float(row[5]),
        }
        for row in raw
    ]
