"""
AltcoinSinyal FastAPI — Production Entry Point

Deploy hedefi: Render.com veya Railway.app
Başlatma komutu (Procfile'dan okunur):
  gunicorn app.main:app -w 2 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT
"""

import logging
import sys
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.config import get_settings
from app.services.exchange import close_exchange, get_exchange
from app.routers import health, market

settings = get_settings()

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=== AltcoinSinyal API başlatılıyor ===")
    logger.info(f"Ortam  : {settings.APP_ENV}")
    logger.info(f"CORS   : {settings.CORS_ORIGINS}")

    # Exchange instance'ı başlat ve piyasa listesini yükle
    exchange = get_exchange()
    try:
        await exchange.load_markets()
        logger.info(f"Binance bağlantısı kuruldu. {len(exchange.markets)} sembol aktif.")
    except Exception as exc:
        logger.warning(f"Piyasa listesi yüklenemedi (devam ediliyor): {exc}")

    yield

    logger.info("=== AltcoinSinyal API kapatılıyor ===")
    await close_exchange()


# ── Uygulama ──────────────────────────────────────────────────────────────────
app = FastAPI(
    title="AltcoinSinyal API",
    version="1.1.0",
    description="Binance destekli altcoin teknik analiz ve sinyal servisi",
    lifespan=lifespan,
    # Production'da Swagger UI kapalı — güvenlik
    docs_url="/docs" if settings.APP_ENV != "production" else None,
    redoc_url=None,
)

# ── Middleware ─────────────────────────────────────────────────────────────────

# GZip — OHLCV gibi büyük yanıtları sıkıştır
app.add_middleware(GZipMiddleware, minimum_size=500)

# CORS — sadece .env'deki CORS_ORIGINS'e izin ver
# Production'da bu liste Vercel URL'sini içermeli
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)

# ── Router'lar ─────────────────────────────────────────────────────────────────
app.include_router(health.router, tags=["sistem"])
app.include_router(market.router, prefix="/api", tags=["piyasa"])

logger.info("Router'lar kaydedildi: /health, /api/ticker, /api/tickers, /api/ohlcv")
